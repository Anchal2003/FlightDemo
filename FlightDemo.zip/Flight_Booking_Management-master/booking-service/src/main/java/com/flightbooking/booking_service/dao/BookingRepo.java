package com.flightbooking.booking_service.dao;

import com.flightbooking.booking_service.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


public interface BookingRepo extends JpaRepository<Booking,Long> {
    Optional<Booking> findByBookingReference(String reference);
}