package com.flightbooking.booking_service.service;

import com.flightbooking.booking_service.dao.BookingRepo;
import com.flightbooking.booking_service.dto.BookingDto;
import com.flightbooking.booking_service.dto.FlightDto;
import com.flightbooking.booking_service.exception.ResourceNotFoundException;
import com.flightbooking.booking_service.feign.FlightFeign;
import com.flightbooking.booking_service.model.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class BookingService {
    @Autowired
    BookingRepo bookingRepo;

    @Autowired
    FlightFeign flightFeign;

    public Booking addBooking(BookingDto bookingRequest) {

        String reference = UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        FlightDto  flightDto= flightFeign.getFlightById(bookingRequest.getFlightId()).getBody();
        if(flightDto==null){
            throw new ResourceNotFoundException("Flight Not Found");
        }

        if(flightDto.getAvailableSeats()>bookingRequest.getNoOfSeats()){
            Booking booking = new Booking();

            booking.setBookingReference(reference);
            booking.setName(bookingRequest.getName());
            booking.setFlightId(bookingRequest.getFlightId());
            booking.setFlightDate(bookingRequest.getFlightDate());
            booking.setSource(bookingRequest.getSource());
            booking.setDestination(bookingRequest.getDestination());
            booking.setNoOfSeats(bookingRequest.getNoOfSeats());
            return bookingRepo.save(booking);
        } else {
            throw new ResourceNotFoundException("Seats not available");
        }

    }


    public Booking getBooking(String reference) {
        return bookingRepo.findByBookingReference(reference)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
    }


}
