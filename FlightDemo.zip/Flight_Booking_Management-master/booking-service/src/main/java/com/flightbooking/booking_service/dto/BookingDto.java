package com.flightbooking.booking_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class BookingDto {


    private long flightId;
    private String source;
    private String destination;
    private String flightDate;

    private String name;
    private String email;
    private  int noOfSeats;
}
