package com.flightbooking.booking_service.controller;

import com.flightbooking.booking_service.dto.BookingDto;
import com.flightbooking.booking_service.model.Booking;
import com.flightbooking.booking_service.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    BookingService bookingService;


    @PostMapping("/book")
    public ResponseEntity<Booking> bookFlight(@RequestBody BookingDto bookDetails){
        Booking booking = bookingService.addBooking(bookDetails);
        return  new ResponseEntity<>(booking, HttpStatus.CREATED);
    }

    @GetMapping("/{reference}")
    public ResponseEntity<Booking> getBooking(@PathVariable String reference) {
        return ResponseEntity.ok(bookingService.getBooking(reference));
    }






}
