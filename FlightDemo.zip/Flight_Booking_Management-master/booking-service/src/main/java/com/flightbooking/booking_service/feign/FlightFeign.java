package com.flightbooking.booking_service.feign;

import com.flightbooking.booking_service.dto.FlightDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "flight-service" , url = "http://localhost:8082")
public interface FlightFeign {

    @GetMapping("/get/{id}")
    public ResponseEntity<FlightDto> getFlightById(@PathVariable Long id);
}
