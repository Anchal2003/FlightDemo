package com.flightbooking.flight_service.service;

import com.flightbooking.flight_service.dao.FlightRepo;
import com.flightbooking.flight_service.exception.ResourceNotFoundException;
import com.flightbooking.flight_service.model.Flight;
import com.flightbooking.flight_service.payload.FlightDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FlightService {

    @Autowired
    FlightRepo flightRepo;


    public Flight createFlight(FlightDto flightDto) {
        Flight flight = new Flight();
        flight.setFlightName(flightDto.getFlightName());
        flight.setId(flightDto.getId());
        flight.setSource(flightDto.getSource());
        flight.setDate(flightDto.getDate());
        flight.setDestination(flightDto.getDestination());
        flight.setFare(flightDto.getFare());
        flight.setNoOfSeats(flightDto.getNoOfSeats());

        flightRepo.save(flight);
        return flight;
    }

    public Flight updateFlightDetails(FlightDto flightDto, Long id) {

        Flight flight = flightRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Flight Not Found"));

        flight.setFlightName(flightDto.getFlightName());
        flight.setSource(flightDto.getSource());
        flight.setDestination(flightDto.getDestination());
        flight.setDate(flightDto.getDate());
        Flight updateDetails = flightRepo.save(flight);


        return flight;
    }

    public void deleteFlightById(Long id) {
        Flight flight = flightRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Flight Not Found"));
        flightRepo.delete(flight);
    }

    public List<Flight> getFlights(String source, String destination, String date) {
        List<Flight> flights = flightRepo.findBySourceAndDestinationAndDate(source, destination, date);
        if (flights.isEmpty()) {
            throw new ResourceNotFoundException("No Flight is available");
        }
        return flights;
    }

    public List<Flight> findAllFlight() {
        return flightRepo.findAll();
    }

    public Flight getFlightById(Long id) {
        return flightRepo.findById(id).orElseThrow(()->  new ResourceNotFoundException("Flight not Found"));
    }
}
