package com.flightbooking.flight_service.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Flight {

    @Id
    private Long Id;
//
//    @NotNull(message = "Flight Name can't be null")
//    @NotEmpty(message = "Flight Name can't be empty")
    private String flightName;
//
//    @NotNull(message = "Source can't be null")
//    @NotEmpty(message = "Source must not be empty")
    private String source;
//
//    @NotNull(message = "Destination can't be null")
//    @NotEmpty(message = "Destination must not be empty")
    private String destination;
//
//    @NotNull
//    @NotEmpty
    private String date;

    private int noOfSeats;

    private static int availableSeats =0;

    private  double fare;


}
