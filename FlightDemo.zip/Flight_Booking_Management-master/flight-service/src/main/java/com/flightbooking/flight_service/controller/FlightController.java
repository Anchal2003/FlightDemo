package com.flightbooking.flight_service.controller;

import com.flightbooking.flight_service.model.Flight;
import com.flightbooking.flight_service.payload.FlightDto;
import com.flightbooking.flight_service.service.FlightService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/flight")
public class FlightController {

    @Autowired
    FlightService flightService;

    @PostMapping("/add")
    public ResponseEntity<Flight> addFlight(@Valid  @RequestBody FlightDto flightDto){
        Flight flight= flightService.createFlight(flightDto);
        return  new ResponseEntity<>(flight,HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Flight> updateFlight(@Valid @RequestBody FlightDto flightDto,@PathVariable Long id){
        Flight flights = flightService.updateFlightDetails(flightDto,id);
        return new ResponseEntity<>(flights,HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public  ResponseEntity<String>  deleteFlight(@PathVariable Long id){
        flightService.deleteFlightById(id);
        return ResponseEntity.ok("Deleted Successfully");
    }

    @GetMapping("/search")
    public ResponseEntity<List<Flight>> searchFlights(@RequestParam String source, @RequestParam String destination, @RequestParam String date){
       List<Flight> flights = flightService.getFlights(source,destination,date);
        return new ResponseEntity<>(flights, HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Flight>> getAllFlight(){
        return new ResponseEntity<>(flightService.findAllFlight(), HttpStatus.OK);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<FlightDto> getFlightById(@PathVariable Long id){
        return new ResponseEntity<>(flightService.getFlightById(id),HttpStatus.OK);
    }
}
