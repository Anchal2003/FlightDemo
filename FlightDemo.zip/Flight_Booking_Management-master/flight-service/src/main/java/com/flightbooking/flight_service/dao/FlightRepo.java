package com.flightbooking.flight_service.dao;

import com.flightbooking.flight_service.model.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FlightRepo extends JpaRepository<Flight,Long> {
    List<Flight> findBySourceAndDestinationAndDate(String source,String destination,String date);

}
