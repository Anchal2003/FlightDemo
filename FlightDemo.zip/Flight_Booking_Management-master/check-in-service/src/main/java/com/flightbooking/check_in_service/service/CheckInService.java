package com.flightbooking.check_in_service.service;

import com.flightbooking.check_in_service.dao.CheckInRepo;
import com.flightbooking.check_in_service.feign.BookingClient;
import com.flightbooking.check_in_service.model.CheckIn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.module.ResolutionException;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class CheckInService {
    @Autowired
    private CheckInRepo checkInRepo;

    @Autowired
    private BookingClient bookingClient;

    public CheckIn checkInPassenger(String bookingReference, String seatNumber) {
        CheckIn checkIn = new CheckIn();
        checkIn.setBookingReference(bookingReference);
        checkIn.setSeatNumber(seatNumber);
        checkIn.setCheckInTime(LocalDateTime.now().toString());
        checkIn.setCheckedIn(true);
         checkInRepo.save(checkIn);

        // Notify booking service
        bookingClient.updateCheckInStatus(bookingReference);

        return checkIn;
    }

    public CheckIn getCheckInByBookingRef(String bookingRef) {
        CheckIn checkIn =  checkInRepo.findByBookingReference(bookingRef).orElseThrow(()->new ResolutionException("booking with reference "+bookingRef+" not found"));
        return checkIn;
    }
}
