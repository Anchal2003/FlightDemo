package com.flightbooking.check_in_service.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient(name = "booking-service", url = "http://localhost:8082") // adjust port accordingly
public interface BookingClient {
    @PutMapping("/bookings/updateCheckInStatus/{bookingRef}")
    void updateCheckInStatus(@PathVariable String bookingRef);
}
