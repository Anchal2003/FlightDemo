package com.flightbooking.check_in_service.controller;

import com.flightbooking.check_in_service.model.CheckIn;
import com.flightbooking.check_in_service.service.CheckInService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/checkin")
public class CheckInController {
    @Autowired
    private CheckInService checkInService;

    @PostMapping
    public ResponseEntity<CheckIn> checkIn(@RequestParam String bookingReference,
                                           @RequestParam String seatNumber) {
        CheckIn result = checkInService.checkInPassenger(bookingReference, seatNumber);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{bookingRef}")
    public ResponseEntity<CheckIn> getCheckIn(@PathVariable String bookingRef) {
        CheckIn checkIn =checkInService.getCheckInByBookingRef(bookingRef);
        return ResponseEntity.ok(checkIn);
    }
}
