package com.flightbooking.check_in_service.dao;

import com.flightbooking.check_in_service.model.CheckIn;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CheckInRepo extends JpaRepository<CheckIn, Long> {
    Optional<CheckIn> findByBookingReference(String bookingReference);
}
