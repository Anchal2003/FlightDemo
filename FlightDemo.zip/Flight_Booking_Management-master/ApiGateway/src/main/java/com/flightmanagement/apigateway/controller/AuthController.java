package com.flightmanagement.apigateway.controller;

import com.flightmanagement.apigateway.dto.LoginDTO;
import com.flightmanagement.apigateway.dto.RegisterDTO;
import com.flightmanagement.apigateway.entity.User;
import com.flightmanagement.apigateway.security.JwtUtil;
import com.flightmanagement.apigateway.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/user")
public class AuthController {

    private final JwtUtil jwtUtil;
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    public AuthController(JwtUtil jwtUtil, UserService userService, PasswordEncoder passwordEncoder) {
        this.jwtUtil = jwtUtil;
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/login")
    public Mono<ResponseEntity<Map<String, String>>> login(@RequestBody LoginDTO loginDTO) {
        String username = loginDTO.getUsername();
        String password = loginDTO.getPassword();

        return Mono.fromCallable(() -> userService.findByUsername(username))
                .flatMap(optionalUser -> {
                    if (optionalUser.isPresent()) {
                        User user = optionalUser.get();
                        if (passwordEncoder.matches(password, user.getPassword())) {
                            String token = jwtUtil.generateToken(username, userService.getUserRoles(user));
                            return Mono.just(ResponseEntity.ok(Map.of("token", token)));
                        }
                    }
                    return Mono.just(ResponseEntity.<Map<String, String>>badRequest().build());
                });
    }

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody RegisterDTO registerDTO) {

        return ResponseEntity.ok(userService.createUser(registerDTO));
    }
}
