package com.flightmanagement.apigateway.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String username;
    private String password;
}
