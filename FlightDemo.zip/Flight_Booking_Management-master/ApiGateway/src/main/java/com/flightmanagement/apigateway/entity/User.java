package com.flightmanagement.apigateway.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(unique = true, nullable = false)
    private String email;

//    @Column(nullable = false)
//    private String roles; // Comma-separated roles

    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> roles; // Store as ["ROLE_USER"], ["ROLE_RECEPTIONIST"], etc.



}
