package com.flightbooking.user_service.service;

import com.flightbooking.user_service.dao.RoleRepo;
import com.flightbooking.user_service.dao.UserRepo;
import com.flightbooking.user_service.exception.ResourceNotFoundException;
import com.flightbooking.user_service.model.Role;
import com.flightbooking.user_service.model.User;
import com.flightbooking.user_service.security.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class UserService {
    @Autowired
    UserRepo userRepo;

    @Autowired
    RoleRepo roleRepo;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JwtService jwtService;

    @Autowired
    AuthenticationManager authenticationManager;

    public User addUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        if (user.getRoles() == null || user.getRoles().isEmpty()) {


            user.setRoles(Set.of(roleRepo.findAll().getFirst()));
        }

        return userRepo.save(user);
    }


    public String verifyUser(User user) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(),user.getPassword()));

        if(authentication.isAuthenticated()){
            return jwtService.generateToken(user.getUsername());
        } else {
            throw new BadCredentialsException("Invalid username or password");

        }
    }

    public User getUserByName(String username) {
        return userRepo.findByUsername(username).orElseThrow(()-> new ResourceNotFoundException("User not found"));
    }
}
