package com.flightbooking.user_service.dao;

import com.flightbooking.user_service.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepo extends JpaRepository<Role,Integer> {
}
