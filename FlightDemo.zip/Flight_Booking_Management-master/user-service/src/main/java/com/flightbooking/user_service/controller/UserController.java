package com.flightbooking.user_service.controller;

import com.flightbooking.user_service.dao.UserRepo;
import com.flightbooking.user_service.model.Role;
import com.flightbooking.user_service.model.User;
import com.flightbooking.user_service.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class UserController {
    @Autowired
    UserRepo userRepo;

    @Autowired
    UserService userService;

    @GetMapping("/home")
    public String getMessage(){
        return "Hello";
    }

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user){
        log.info("user registration");
        User addedUser = userService.addUser(user);
        return ResponseEntity.ok(addedUser);
    }

    @PostMapping("/login")
    public String loginUser(@RequestBody  User user){
        log.info("user login");
       return userService.verifyUser(user);
    }

    @GetMapping("get/{username}")
    public User getUserByUsername(@PathVariable String username){
        return userService.getUserByName(username);
    }
}
